import { Component } from '@angular/core';
import { NhanVien } from '../nhan-vien';
import { DetailService } from '../detail.service';
import {
  FormControl,
  FormGroup,
  RequiredValidator,
  Validators,
} from '@angular/forms';
@Component({
  selector: 'app-duan-them',
  templateUrl: './duan-them.component.html',
  styleUrls: ['./duan-them.component.css'],
})
export class DuanThemComponent {
  listNhanVien: NhanVien[] = [];
  frm1!: FormGroup;
  constructor(private projectsService: DetailService) {}
  ngOnInit() {
    this.projectsService.getNhanVien().subscribe((data) => {
      this.listNhanVien = <NhanVien[]>data;
    });
    this.frm1 = new FormGroup({
      tenDuAn: new FormControl('', [
        Validators.minLength(3),
        Validators.required,
      ]),
      ngayStart: new FormControl('', Validators.required),
      tien: new FormControl('', [Validators.min(0)]),
      leader: new FormControl('', Validators.required),
      thanhvien: new FormControl(''),
    });
  }
  createDA(data: any) {
    console.log(data);
  }
}
