import { Component } from '@angular/core';
import { DuAn } from '../du-an';
import { NhanVien } from '../nhan-vien';
import { DetailService } from '../detail.service';
@Component({
  selector: 'app-task-them',
  templateUrl: './task-them.component.html',
  styleUrls: ['./task-them.component.css'],
})
export class TaskThemComponent {
  listDA: DuAn[] = [];
  listNV: NhanVien[] = [];
  constructor(private projectsService: DetailService) {}
  ngOnInit() {
    this.projectsService.getProjects().subscribe((data) => {
      this.listDA = <DuAn[]>data;
    });
    this.projectsService.getNhanVien().subscribe((data) => {
      this.listNV = <NhanVien[]>data;
    });
  }
}
