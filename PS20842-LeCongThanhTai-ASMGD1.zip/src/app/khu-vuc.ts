export interface KhuVuc {
    [key:string]:number
}