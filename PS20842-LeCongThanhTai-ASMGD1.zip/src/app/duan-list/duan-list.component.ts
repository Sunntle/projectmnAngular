import { Component } from '@angular/core';
import { DuAn } from '../du-an';
import { DetailService } from '../detail.service';
import { Subscription } from 'rxjs';
@Component({
  selector: 'app-duan-list',
  templateUrl: './duan-list.component.html',
  styleUrls: ['./duan-list.component.css'],
})
export class DuanListComponent {
  dataDA: DuAn = {
    id: 0,
    tenDuAn: '',
    ngayStart: '',
    tien: 0,
    leader: 0,
    thanhvien: [],
  };
  listDuAn: DuAn[] = [];
  constructor(private projectsService: DetailService) {}
  ngOnInit() {
    this.projectsService.getProjects().subscribe((data) => {
      this.listDuAn = <DuAn[]>data;
    });
  }
  getData(id: number) {
    this.dataDA = this.listDuAn.find((el) => el.id === id)!;
  }
  getValueSort(event: any) {
    const selectValue = +event.target.value;
    switch (selectValue) {
      case 1:
        this.sortArr(this.listDuAn, 'min', 'date');
        break;
      case 2:
        this.sortArr(this.listDuAn, 'max', 'date');
        break;
      case 3:
        this.sortArr(this.listDuAn, 'min', 'price');
        break;
      case 4:
        this.sortArr(this.listDuAn, 'max', 'price');
        break;
      default:
        this.sortArr(this.listDuAn, '', '');
        break;
    }
  }
  sortArr(arr: DuAn[], status: string, sortBy: string) {
    arr.sort((a, b) => {
      let a1 = 0;
      let a2 = 0;
      if (sortBy == 'date') {
        a1 = new Date(a.ngayStart).valueOf();
        a2 = new Date(b.ngayStart).valueOf();
      } else if (sortBy == 'price') {
        a1 = a.tien;
        a2 = b.tien;
      } else {
        a1 = a.id;
        a2 = b.id;
      }
      let result = a1 - a2;
      if (status == 'max') {
        result = a2 - a1;
      }
      return result;
    });
    return arr;
  }
  private subscription: Subscription = new Subscription();
  ngOnDestroy() {
    if (this.subscription) {
      this.subscription.unsubscribe();
    }
  }
}
