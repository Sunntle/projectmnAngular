import { Component } from '@angular/core';
import { NhanVien } from '../nhan-vien';
import { DetailService } from '../detail.service';
import { Subscription } from 'rxjs';
@Component({
  selector: 'app-nv-list',
  templateUrl: './nv-list.component.html',
  styleUrls: ['./nv-list.component.css'],
})
export class NvListComponent {
  listNhanVien: NhanVien[] = [];
  constructor(private projectsService: DetailService) {}
  ngOnInit() {
    this.projectsService.getNhanVien().subscribe((data) => {
      this.listNhanVien = <NhanVien[]>data;
    });
  }
  private subscription: Subscription = new Subscription();
  ngOnDestroy() {
    if (this.subscription) {
      this.subscription.unsubscribe();
    }
  }
}
