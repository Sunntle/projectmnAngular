export interface NhiemVu {
    
    id:number;
    tenTask:string;
    moTa:string;
    duAnID:number;
    nhanvienID:number;
    priority:number;
    status:number;
}
