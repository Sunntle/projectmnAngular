export interface NhanVien {
    id:number;
    ho:string;
    ten:string;
    ngaysinh:string;
    phai:boolean;
    khuvuc:string;
}
