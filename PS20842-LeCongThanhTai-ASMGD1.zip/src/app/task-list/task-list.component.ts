import { Component, EventEmitter, Output } from '@angular/core';
import { NhiemVu } from '../nhiem-vu';
@Component({
  selector: 'app-task-list',
  templateUrl: './task-list.component.html',
  styleUrls: ['./task-list.component.css'],
})
export class TaskListComponent {
  listTask: NhiemVu[] = [
    {
      id: 1,
      tenTask: 'Phân tích yêu cầu',
      duAnID: 1,
      nhanvienID: 1,
      moTa: 'Phân tích yêu cầu...',
      status: 0,
      priority: 1,
    },
    {
      id: 2,
      tenTask: 'Thực hiện layout',
      duAnID: 1,
      nhanvienID: 2,
      moTa: 'Thực hiện layout...',
      status: 0,
      priority: 1,
    },
    {
      id: 3,
      tenTask: 'Tìm hiểu yêu cầu khách hàng',
      duAnID: 2,
      nhanvienID: 3,
      moTa: 'Tìm hiểu yêu cầu khách hàng...',
      status: 0,
      priority: 2,
    },
  ];
}
