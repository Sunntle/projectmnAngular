export interface DuAn {
    id:number;
    tenDuAn:string;
    ngayStart:string;
    tien:number;
    leader:number;
    thanhvien:number[];
}
